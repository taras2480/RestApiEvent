package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.PersistentEntityResource;
import org.springframework.data.rest.webmvc.PersistentEntityResourceAssembler;
import org.springframework.data.rest.webmvc.RepositoryRestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.controller.exception.AlreadyCheckedInException;
import com.example.demo.entities.Participant;
import com.example.demo.repositories.ParticipantRepository;

@RepositoryRestController
@RequestMapping("/events")
public class CheckInController {

	@Autowired
	private ParticipantRepository participantRepository;

	@PostMapping("/checkIn/{id}")
	public ResponseEntity<PersistentEntityResource> checkIn(@PathVariable Long id,PersistentEntityResourceAssembler assembler) {

		Participant participant = participantRepository.findById(id).get();

		if (participant != null) {
			if (participant.getCheckedIn()) {
				throw new AlreadyCheckedInException();
			}
			participant.setCheckedIn(true);
			participantRepository.save(participant);
		}
		

		return ResponseEntity.ok(assembler.toFullResource(participant));

	}
	@PostMapping("/checkOut/{id}")
	public ResponseEntity<PersistentEntityResource> checkOut(@PathVariable Long id,PersistentEntityResourceAssembler assembler) {

		Participant participant = participantRepository.findById(id).get();

		if (participant != null) {
			if (participant.getCheckedIn()) {
				participant.setCheckedIn(false);
				participantRepository.save(participant);
			}
			
		}
		

		return ResponseEntity.ok(assembler.toFullResource(participant));

	}

}
