package com.example.demo.repositories;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.demo.entities.Venue;

public interface VenueRepository extends PagingAndSortingRepository<Venue, Long> {

}
