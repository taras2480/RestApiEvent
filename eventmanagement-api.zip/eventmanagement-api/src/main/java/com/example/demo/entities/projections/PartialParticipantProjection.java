package com.example.demo.entities.projections;

import org.springframework.data.rest.core.config.Projection;

import com.example.demo.entities.Participant;

@Projection(name = "partialParticipant", types = { Participant.class })
public interface PartialParticipantProjection {
	
	String getName();

	Boolean getCheckedIn();

}
