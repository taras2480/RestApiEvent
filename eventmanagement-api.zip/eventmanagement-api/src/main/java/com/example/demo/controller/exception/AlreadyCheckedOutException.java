package com.example.demo.controller.exception;

public class AlreadyCheckedOutException extends RuntimeException {

}
