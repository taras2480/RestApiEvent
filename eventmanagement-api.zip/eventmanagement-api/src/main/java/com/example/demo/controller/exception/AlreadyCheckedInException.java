package com.example.demo.controller.exception;

public class AlreadyCheckedInException extends RuntimeException {

}
